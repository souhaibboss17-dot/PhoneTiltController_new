# Phone Tilt Controller (prototype)

A minimal Android Kotlin project that reads accelerometer tilt and sends angle values over Bluetooth Classic RFCOMM between two paired Android phones. Run the same APK on both phones: choose **Connect as controller** on the phone used as a controller and enter the receiver phone's Bluetooth MAC address; choose **Start receiver** on the other phone.

## Build

The included GitHub Actions workflow builds a debug APK on pushes to `main`/`master` or when manually run from Actions. Download the artifact named `PhoneTiltController-debug-apk` from a successful workflow run.

## Important limitation

This prototype transmits and displays tilt values only. It does not control Rally Fury or inject touch/controller input into another app. That would require a separate, compatible input integration and testing on the target phones. Bluetooth pairing and permissions are required; Bluetooth availability and device-specific behavior may vary.
