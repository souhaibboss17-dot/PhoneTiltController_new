package com.example.phonetiltcontroller

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.atan2
import kotlin.math.roundToInt

class MainActivity : Activity(), SensorEventListener {
    private val serviceUuid: UUID = UUID.fromString("9f3d6a90-6a7e-4c3d-9f3a-5e2d0b8c1a11")
    private var bluetooth: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var serverSocket: BluetoothServerSocket? = null
    private var writer: PrintWriter? = null
    private var sensorManager: SensorManager? = null
    private var latestAngle = 0
    private var connected = false
    private lateinit var status: TextView
    private lateinit var angleView: TextView
    private lateinit var addressInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bluetooth = BluetoothAdapter.getDefaultAdapter()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        buildUi()
        requestBluetoothPermissionIfNeeded()
        sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.also {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        if (bluetooth == null) setStatus("This phone does not support Bluetooth.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
        }
        val scroll = ScrollView(this)
        val title = TextView(this).apply {
            text = "Phone Tilt Controller"
            textSize = 25f
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        angleView = TextView(this).apply {
            text = "Tilt: 0°"
            textSize = 34f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        root.addView(angleView, matchWrap())
        addressInput = EditText(this).apply {
            hint = "Receiver phone Bluetooth MAC address"
            singleLine = true
            setText("")
        }
        root.addView(addressInput, matchWrap())
        root.addView(makeButton("Connect as controller") { connectAsController() }, matchWrap())
        root.addView(makeButton("Start receiver") { startReceiver() }, matchWrap())
        root.addView(makeButton("Disconnect") { disconnect() }, matchWrap())
        status = TextView(this).apply {
            text = "Choose a role. Pair the phones in Android Bluetooth settings first."
            textSize = 15f
            setPadding(0, 20, 0, 0)
        }
        root.addView(status, matchWrap())
        val note = TextView(this).apply {
            text = "Controller mode sends tilt values over Bluetooth. Receiver mode displays them. This prototype does not inject steering into Rally Fury; game control needs a separate supported input/accessibility integration."
            textSize = 13f
            setPadding(0, 24, 0, 0)
        }
        root.addView(note, matchWrap())
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun matchWrap(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 12 }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 200)
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectAsController() {
        val adapter = bluetooth ?: return setStatus("Bluetooth is not available.")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionIfNeeded()
            return setStatus("Allow Nearby devices permission, then tap Connect again.")
        }
        val address = addressInput.text.toString().trim()
        if (address.isBlank()) return setStatus("Enter the receiver phone's Bluetooth MAC address.")
        disconnect()
        setStatus("Connecting to $address …")
        thread {
            try {
                val device = adapter.getRemoteDevice(address)
                val newSocket = device.createRfcommSocketToServiceRecord(serviceUuid)
                newSocket.connect()
                socket = newSocket
                writer = PrintWriter(newSocket.outputStream, true)
                connected = true
                runOnUiThread { setStatus("Connected. Tilt this phone to send steering values.") }
            } catch (e: Exception) {
                runOnUiThread { setStatus("Connection failed: ${e.message ?: "check pairing and MAC address"}") }
                disconnect()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startReceiver() {
        val adapter = bluetooth ?: return setStatus("Bluetooth is not available.")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionIfNeeded()
            return setStatus("Allow Nearby devices permission, then tap Start receiver again.")
        }
        disconnect()
        setStatus("Receiver is waiting for a paired controller…")
        thread {
            try {
                val server = adapter.listenUsingRfcommWithServiceRecord("PhoneTiltController", serviceUuid)
                serverSocket = server
                val incoming = server.accept()
                socket = incoming
                connected = true
                runOnUiThread { setStatus("Controller connected. Receiving tilt values.") }
                val reader = BufferedReader(InputStreamReader(incoming.inputStream))
                while (connected) {
                    val line = reader.readLine() ?: break
                    val value = line.toIntOrNull() ?: continue
                    runOnUiThread {
                        angleView.text = "Received tilt: ${value}°"
                    }
                }
            } catch (e: Exception) {
                if (connected) runOnUiThread { setStatus("Receiver stopped: ${e.message ?: "connection ended"}") }
            } finally {
                disconnect()
            }
        }
    }

    private fun disconnect() {
        connected = false
        try { writer?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        writer = null
        socket = null
        serverSocket = null
    }

    private fun setStatus(message: String) {
        if (::status.isInitialized) status.text = message
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val z = event.values[2]
        latestAngle = atan2(x.toDouble(), z.toDouble()).let { Math.toDegrees(it).roundToInt().coerceIn(-90, 90) }
        angleView.text = "Tilt: ${latestAngle}°"
        if (connected) {
            try { writer?.println(latestAngle) } catch (_: Exception) {}
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onDestroy() {
        sensorManager?.unregisterListener(this)
        disconnect()
        super.onDestroy()
    }
}
