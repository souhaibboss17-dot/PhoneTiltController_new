# Phone Tilt Controller

A small Android prototype that reads the phone accelerometer and can send tilt-angle values to another paired Android phone over Bluetooth Classic.

## Build
The GitHub Actions workflow in `.github/workflows/build.yml` extracts `PhoneTiltController-New.zip` and builds a debug APK using Java 17 and Gradle 8.9.

## Important limitation
This prototype only transfers angle values between phones. It does **not** directly control Rally Fury, simulate a gamepad, or inject touch controls into another app. That would require a separate, supported input/bridge method.
