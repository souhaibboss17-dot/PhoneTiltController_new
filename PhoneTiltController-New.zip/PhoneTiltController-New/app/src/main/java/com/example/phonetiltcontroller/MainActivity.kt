package com.example.phonetiltcontroller

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.atan2
import kotlin.math.sqrt

class MainActivity : Activity(), SensorEventListener {
    private val serviceName = "PhoneTiltController"
    private val serviceUuid: UUID = UUID.fromString("8b7d4e2a-6f31-4c8d-9a21-1b7f2c6d4e90")
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var serverSocket: BluetoothServerSocket? = null
    @Volatile private var writer: PrintWriter? = null
    @Volatile private var running = false
    private lateinit var statusText: TextView
    private lateinit var angleText: TextView
    private lateinit var receiverText: TextView
    private var lastSendAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        buildUi()
        if (bluetoothAdapter == null) {
            statusText.text = "Bluetooth is not available on this phone."
        } else if (accelerometer == null) {
            statusText.text = "This phone has no accelerometer sensor."
        } else {
            statusText.text = "Ready. Choose Sender on the phone you tilt."
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "Phone Tilt Controller"
            textSize = 26f
        }
        statusText = TextView(this).apply {
            textSize = 16f
            setPadding(0, 16, 0, 16)
        }
        angleText = TextView(this).apply {
            text = "Tilt angle: 0°"
            textSize = 22f
            setPadding(0, 8, 0, 8)
        }
        receiverText = TextView(this).apply {
            text = "Received tilt: waiting"
            textSize = 20f
            setPadding(0, 8, 0, 8)
        }
        val senderButton = Button(this).apply {
            text = "Start Sender (tilt this phone)"
            setOnClickListener { startSender() }
        }
        val receiverButton = Button(this).apply {
            text = "Start Receiver (other phone)"
            setOnClickListener { startReceiver() }
        }
        val stopButton = Button(this).apply {
            text = "Stop"
            setOnClickListener { stopConnection() }
        }
        val note = TextView(this).apply {
            text = "Important: this prototype sends tilt-angle data between two phones over Bluetooth. It does not directly control Rally Fury or create a game controller input."
            textSize = 14f
            setPadding(0, 18, 0, 0)
        }
        content.addView(title)
        content.addView(statusText)
        content.addView(angleText)
        content.addView(receiverText)
        content.addView(senderButton)
        content.addView(receiverButton)
        content.addView(stopButton)
        content.addView(note)
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun hasBluetoothPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val granted = checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            requestPermissions(
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN),
                200
            )
        }
        return granted
    }

    private fun startSender() {
        val adapter = bluetoothAdapter ?: return
        if (!hasBluetoothPermission()) {
            statusText.text = "Allow nearby-device Bluetooth permission, then tap Sender again."
            return
        }
        if (!adapter.isEnabled) {
            statusText.text = "Turn Bluetooth on in Android Settings, then try again."
            return
        }
        stopConnection()
        running = true
        sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME)
        statusText.text = "Sender ready. Pair the phones in Android Bluetooth settings first, then start Receiver on the other phone."
        thread {
            while (running) {
                try {
                    val paired: Set<BluetoothDevice> = adapter.bondedDevices
                    val device = paired.firstOrNull()
                    if (device == null) {
                        runOnUiThread { statusText.text = "No paired Bluetooth device. Pair the phones in Settings first." }
                        Thread.sleep(1500)
                        continue
                    }
                    val newSocket = device.createRfcommSocketToServiceRecord(serviceUuid)
                    socket = newSocket
                    newSocket.connect()
                    writer = PrintWriter(newSocket.outputStream, true)
                    runOnUiThread { statusText.text = "Connected as sender to ${device.name ?: "paired phone"}." }
                    while (running && newSocket.isConnected) {
                        Thread.sleep(100)
                    }
                } catch (e: Exception) {
                    runOnUiThread { if (running) statusText.text = "Sender connection failed: ${e.message ?: "check pairing"}" }
                    try { Thread.sleep(1500) } catch (_: InterruptedException) {}
                } finally {
                    try { socket?.close() } catch (_: Exception) {}
                    socket = null
                    writer = null
                }
            }
        }
    }

    private fun startReceiver() {
        val adapter = bluetoothAdapter ?: return
        if (!hasBluetoothPermission()) {
            statusText.text = "Allow nearby-device Bluetooth permission, then tap Receiver again."
            return
        }
        if (!adapter.isEnabled) {
            statusText.text = "Turn Bluetooth on in Android Settings, then try again."
            return
        }
        stopConnection()
        running = true
        statusText.text = "Receiver waiting. Pair the phones in Android Bluetooth settings."
        thread {
            try {
                val server = adapter.listenUsingRfcommWithServiceRecord(serviceName, serviceUuid)
                serverSocket = server
                val accepted = server.accept()
                socket = accepted
                runOnUiThread { statusText.text = "Receiver connected." }
                val reader = BufferedReader(InputStreamReader(accepted.inputStream))
                while (running) {
                    val line = reader.readLine() ?: break
                    runOnUiThread { receiverText.text = "Received tilt: $line" }
                }
            } catch (e: Exception) {
                runOnUiThread { if (running) statusText.text = "Receiver stopped: ${e.message ?: "connection error"}" }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
                try { serverSocket?.close() } catch (_: Exception) {}
                socket = null
                serverSocket = null
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        val angle = Math.toDegrees(atan2(x.toDouble(), sqrt((y * y + z * z).toDouble()))).toInt()
        angleText.text = "Tilt angle: ${angle}°"
        val now = System.currentTimeMillis()
        if (running && now - lastSendAt >= 100L) {
            lastSendAt = now
            writer?.println(angle)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun stopConnection() {
        running = false
        sensorManager?.unregisterListener(this)
        try { writer?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        writer = null
        socket = null
        serverSocket = null
        statusText.text = "Stopped."
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200 && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            statusText.text = "Permission granted. Tap Sender or Receiver again."
        } else if (requestCode == 200) {
            statusText.text = "Bluetooth permission was not granted."
        }
    }

    override fun onDestroy() {
        stopConnection()
        super.onDestroy()
    }
}
